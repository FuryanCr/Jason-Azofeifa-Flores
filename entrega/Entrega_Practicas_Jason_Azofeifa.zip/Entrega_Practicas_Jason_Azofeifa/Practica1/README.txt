PRACTICA 1 - Ventana "Olvidó mi contraseña"
Ejecutar:  java -jar Practica1.jar
Código fuente en la carpeta src (FrmOlvido, UsuarioDAO, UsuarioDAOImpl, FrmLogin, Main, Estilo).
