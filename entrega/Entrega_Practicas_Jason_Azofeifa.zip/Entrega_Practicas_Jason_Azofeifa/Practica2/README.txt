PRACTICA 2 - Recuperación de contraseña con SHA-256 + salt
Ejecutar:  java -jar Practica2.jar      (cuenta de prueba: demo@correo.com / Demo1234)
Prueba de consola:  java -cp Practica2.jar PruebaSeguridad
Código fuente en la carpeta src (IAutenticacion, UsuarioDAO, UsuarioDAOImpl, SeguridadClave, FrmOlvido, ...).
